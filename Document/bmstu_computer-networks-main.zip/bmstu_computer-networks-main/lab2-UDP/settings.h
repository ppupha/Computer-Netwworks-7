#ifndef INFO_H
#define INFO_H

#define MSG_LEN 10
#define RES_LEN 40
#define SRV_IP "127.0.0.1"
#define SOCK_PORT 8888

#endif // INFO_H
