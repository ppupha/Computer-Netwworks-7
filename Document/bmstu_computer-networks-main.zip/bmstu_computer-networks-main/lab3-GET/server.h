#ifndef SOCKET_H
#define SOCKET_H

#define SOCK_ADDR "localhost"
#define SOCK_PORT 23232
#define MSG_LEN 500

#endif // SOCKET_H
